<!--
 * @Description: 重置密码
 * @Version: 1.0
 * @Autor: tzhhone
 * @Date: 2021-09-16 18:30:27
 * @LastEditors: tzhhone
 * @LastEditTime: 2021-09-16 18:30:27
-->

<template>
    <h1>重置密码</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>