<div style="max-width:800px;margin-left: auto;margin-right: auto;">
<img src="static/img/404-2.png"/>
<button class="el-input__inner" id="boom" autocomplete="off" onclick="javascript:history.go(-1);">返回</button>
</div>


